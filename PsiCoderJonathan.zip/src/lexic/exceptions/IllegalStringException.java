package lexic.exceptions;

public class IllegalStringException extends RuntimeException {
    
    public IllegalStringException() {}
}
