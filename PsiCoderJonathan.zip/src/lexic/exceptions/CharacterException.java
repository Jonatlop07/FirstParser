package lexic.exceptions;

public class CharacterException extends RuntimeException {
    
    public CharacterException() {}
}
