class IllegalStringException extends RuntimeException {
    
    public IllegalStringException() {}
}
