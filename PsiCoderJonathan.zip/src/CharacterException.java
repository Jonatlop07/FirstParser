public class CharacterException extends RuntimeException {
    
    public CharacterException() {}
}
