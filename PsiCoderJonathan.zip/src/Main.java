import lexic.Lexer;
import model.token.Token;

import java.io.*;

public class Main {
    
    private static Lexer lexer;
    private static String buffer;
    
    public static void main( String[] args ) {
        
        try ( BufferedReader reader = new BufferedReader( new InputStreamReader( System.in ) ) ) {
            String line = "";
            buffer = "";
            
            do {
                buffer += line;
            } while ( (line = reader.readLine()).length() > 0 );
            
        } catch ( IOException e ) {
            e.printStackTrace();
        }
        
        lexer = Lexer.getInstance( buffer );
        
        Token currentToken = null;
        
        do {
            currentToken = lexer.getNextToken();
            
            if ( currentToken != null ) {
                System.out.println( currentToken );
            }
            
        } while ( currentToken != null );
    }
}
