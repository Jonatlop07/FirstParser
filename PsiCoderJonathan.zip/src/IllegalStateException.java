class IllegalStateException extends RuntimeException {
    
    public IllegalStateException() {}
}
